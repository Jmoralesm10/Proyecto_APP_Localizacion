package com.API.API_Localizacion;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiLocalizacionApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiLocalizacionApplication.class, args);
	}

}
