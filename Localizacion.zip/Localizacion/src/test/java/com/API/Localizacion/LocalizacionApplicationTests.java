package com.API.Localizacion;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LocalizacionApplicationTests {

	@Test
	void contextLoads() {
	}

}
